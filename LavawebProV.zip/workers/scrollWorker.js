self.onmessage = function(event) {
    const deltaY = event.data.deltaY;
    const progress = event.data.progress;
    const progressTo = event.data.progressTo;

    // Тяжелые вычисления для обработки скролла
    const newProgressTo = progressTo - deltaY / 1000;

    self.postMessage({ newProgressTo });
};